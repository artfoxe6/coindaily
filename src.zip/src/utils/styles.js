
export default Styles = {

	common:{
		theme:'green',
		statusbar:'red',
	},
	index:{

	},
	tab1:{

	},
	tab2:{

	},
	tab3:{

	},
	tab4:{
		
	}
}