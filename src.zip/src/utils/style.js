
const style = {

    theme:{
        bcolor:'#4EBAC8', //rgba(51,69,83,1)
        ocolor:'rgba(51,69,83,0.1)'
    }
}
export default style;